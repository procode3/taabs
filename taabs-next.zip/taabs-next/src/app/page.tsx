import Image from "next/image";

export default function Home() {
	return (
		<div className=" w-full min-w-[25rem] max-h-[37.5rem] h-full flex flex-col justify-between gap-5 text-sm bg-white overflow-hidden text-black ">
			<header className="p-7 flex items-center justify-between border-b">
				<h1 className="header-title font-bold text-[1.5rem]">Taabs</h1>
				<div className="flex gap-2">
					<div className="relative w-[22px] h-[22px] cursor-pointer">
						<Image
							src="/images/settingsicon.png"
							alt="Settings Icon"
							fill
							style={{ objectFit: "contain" }}
						/>
					</div>
					<div className="relative w-[22px] h-[22px] cursor-pointer">
						<Image
							src="/images/settingsicon.png"
							alt="Settings Icon"
							fill
							style={{ objectFit: "contain" }}
						/>
					</div>
					<div className="relative w-[22px] h-[22px] cursor-pointer">
						<Image
							src="/images/settingsicon.png"
							alt="Settings Icon"
							fill
							style={{ objectFit: "contain" }}
						/>
					</div>
				</div>
			</header>
			<div>
				<section className="p-10 flex flex-col gap-5">
					<div className="flex justify-between items-center">
						<p>Lazy Loading</p>
						<div>Toggle</div>
					</div>
					<div className="flex flex-col gap-1">
						<p>Manage Tabs</p>
						<div className="flex justify-between items-center">
							<p>0 slected</p>
							<div> Search Imput</div>
							<div className="flex gap-3">
								<div className="relative w-[22px] h-[22px] cursor-pointer">
									<Image
										src="/images/settingsicon.png"
										alt="Settings Icon"
										fill
										style={{ objectFit: "contain" }}
									/>
								</div>
								<div className="relative w-[22px] h-[22px] cursor-pointer">
									<Image
										src="/images/settingsicon.png"
										alt="Settings Icon"
										fill
										style={{ objectFit: "contain" }}
									/>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section className="px-10 flex flex-col gap-2 overflow-hidden h-[250px]">
					<h2>Open Tabs</h2>
					<div className="flex flex-col gap-2 overflow-y-scroll">
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
						<div className="flex gap-2 items-center">
							<div>o</div>
							<div className="w-full flex justify-end px-2 py-1.5 bg-gray-200 items-center">
								x
							</div>
						</div>
					</div>
				</section>
			</div>

			<footer className="p-5 flex gap-1 text-xs items-center justify-center">
				<p>Terms of Service and Privacy Policy</p>
				<div className="relative w-[18px] h-[18px] cursor-pointer">
					<Image
						src="/images/settingsicon.png"
						alt="Settings Icon"
						fill
						style={{ objectFit: "contain" }}
					/>
				</div>
			</footer>
		</div>
	);
}
